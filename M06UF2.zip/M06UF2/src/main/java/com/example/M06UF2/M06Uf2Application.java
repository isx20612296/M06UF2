package com.example.M06UF2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M06Uf2Application {

	public static void main(String[] args) {
		SpringApplication.run(M06Uf2Application.class, args);
	}

}
