package com.example.M06UF2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M06Uf2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
